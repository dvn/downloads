Copy these files into your .../glassfish/domains/domain1/config/ directory. 

